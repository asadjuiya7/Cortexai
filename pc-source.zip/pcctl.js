// Cortex "Laptop Tool": everything Cortex can do on a Windows PC.
// Runs in the Electron main process, which has full access to the operating system.
const { execFile, exec } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');

// ------------------------------------------------------------------ helpers
function ps(script, param, timeout) {
  return new Promise((resolve) => {
    if (process.platform !== 'win32') return resolve({ ok: false, out: '', err: 'This works only on Windows.' });
    execFile(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script],
      { env: { ...process.env, CX_P: String(param == null ? '' : param) }, windowsHide: true, timeout: timeout || 20000, maxBuffer: 1 << 20 },
      (err, out, errout) => resolve({ ok: !err, out: String(out || '').trim(), err: String((errout || (err && err.message)) || '').trim() })
    );
  });
}

const SENDKEYS = 'Add-Type -AssemblyName System.Windows.Forms; ';
const num = (v, d) => {
  const n = parseInt(String(v).replace(/[^\d-]/g, ''), 10);
  return Number.isFinite(n) ? n : d;
};
const clamp = (n, a, b) => Math.max(a, Math.min(b, n));

// ------------------------------------------------------------------ apps
const APPS = {
  chrome: 'chrome', 'google chrome': 'chrome', edge: 'msedge', 'microsoft edge': 'msedge', firefox: 'firefox', brave: 'brave',
  notepad: 'notepad', calculator: 'calc', calc: 'calc', paint: 'mspaint', word: 'winword', winword: 'winword', excel: 'excel',
  powerpoint: 'powerpnt', powerpnt: 'powerpnt', outlook: 'outlook', explorer: 'explorer', 'file explorer': 'explorer', files: 'explorer',
  cmd: 'cmd', 'command prompt': 'cmd', powershell: 'powershell', terminal: 'wt', 'task manager': 'taskmgr', taskmgr: 'taskmgr',
  vscode: 'code', 'vs code': 'code', 'visual studio code': 'code', 'snipping tool': 'snippingtool', snip: 'snippingtool',
  'control panel': 'control', 'device manager': 'devmgmt.msc', 'disk management': 'diskmgmt.msc',
  settings: 'ms-settings:', 'wi-fi settings': 'ms-settings:network-wifi', 'bluetooth settings': 'ms-settings:bluetooth',
  camera: 'microsoft.windows.camera:', store: 'ms-windows-store:', 'microsoft store': 'ms-windows-store:',
  clock: 'ms-clock:', alarms: 'ms-clock:', photos: 'ms-photos:', maps: 'bingmaps:', calendar: 'outlookcal:', mail: 'mailto:',
  whatsapp: 'whatsapp:', spotify: 'spotify:', telegram: 'tg:', discord: 'discord:', steam: 'steam:', teams: 'msteams:', zoom: 'zoommtg:',
};
const SITES = {
  youtube: 'https://www.youtube.com', gmail: 'https://mail.google.com', google: 'https://www.google.com', facebook: 'https://www.facebook.com',
  instagram: 'https://www.instagram.com', twitter: 'https://x.com', x: 'https://x.com', linkedin: 'https://www.linkedin.com',
  github: 'https://github.com', netflix: 'https://www.netflix.com', daraz: 'https://www.daraz.pk', amazon: 'https://www.amazon.com',
  chatgpt: 'https://chat.openai.com', reddit: 'https://www.reddit.com', tiktok: 'https://www.tiktok.com', 'whatsapp web': 'https://web.whatsapp.com',
};
const SEARCH = {
  youtube: 'https://www.youtube.com/results?search_query=', google: 'https://www.google.com/search?q=',
  maps: 'https://www.google.com/maps/search/', 'google maps': 'https://www.google.com/maps/search/',
  amazon: 'https://www.amazon.com/s?k=', daraz: 'https://www.daraz.pk/catalog/?q=', spotify: 'https://open.spotify.com/search/',
  wikipedia: 'https://en.wikipedia.org/w/index.php?search=', github: 'https://github.com/search?q=', facebook: 'https://www.facebook.com/search/top?q=',
  twitter: 'https://x.com/search?q=', x: 'https://x.com/search?q=', linkedin: 'https://www.linkedin.com/search/results/all/?keywords=',
  pinterest: 'https://www.pinterest.com/search/pins/?q=', tiktok: 'https://www.tiktok.com/search?q=', reddit: 'https://www.reddit.com/search/?q=',
  imdb: 'https://www.imdb.com/find/?q=', stackoverflow: 'https://stackoverflow.com/search?q=', netflix: 'https://www.netflix.com/search?q=',
  gmail: 'https://mail.google.com/mail/u/0/#search/', bing: 'https://www.bing.com/search?q=', chatgpt: 'https://chat.openai.com/?q=',
};
const FOLDERS = {
  downloads: 'downloads', download: 'downloads', documents: 'documents', docs: 'documents', desktop: 'desktop',
  pictures: 'pictures', photos: 'pictures', music: 'music', videos: 'videos', home: 'home', temp: 'temp',
};
const NEVER_KILL = /^(system|csrss|winlogon|svchost|lsass|services|wininit|smss|dwm|registry|explorer)$/i;
const PROC = { chrome: 'chrome', edge: 'msedge', firefox: 'firefox', word: 'winword', excel: 'excel', powerpoint: 'powerpnt', notepad: 'notepad', spotify: 'spotify', whatsapp: 'whatsapp', vscode: 'code', teams: 'ms-teams', zoom: 'zoom', vlc: 'vlc' };

// Key names understood by press_keys.
const SPECIAL = {
  enter: '{ENTER}', return: '{ENTER}', tab: '{TAB}', esc: '{ESC}', escape: '{ESC}', delete: '{DELETE}', del: '{DELETE}', backspace: '{BACKSPACE}',
  home: '{HOME}', end: '{END}', pageup: '{PGUP}', pagedown: '{PGDN}', up: '{UP}', down: '{DOWN}', left: '{LEFT}', right: '{RIGHT}', space: ' ',
  f1: '{F1}', f2: '{F2}', f3: '{F3}', f4: '{F4}', f5: '{F5}', f6: '{F6}', f7: '{F7}', f8: '{F8}', f9: '{F9}', f10: '{F10}', f11: '{F11}', f12: '{F12}',
};
function keysToSendKeys(spec) {
  const parts = String(spec || '').toLowerCase().split('+').map((s) => s.trim()).filter(Boolean);
  if (!parts.length) return null;
  let mods = '';
  let key = '';
  for (const p of parts) {
    if (p === 'ctrl' || p === 'control') mods += '^';
    else if (p === 'alt') mods += '%';
    else if (p === 'shift') mods += '+';
    else if (p === 'win' || p === 'windows') return null; // handled separately
    else key = SPECIAL[p] || (p.length === 1 ? (/[+^%~(){}\[\]]/.test(p) ? '{' + p + '}' : p) : null);
    if (key === null) return null;
  }
  return key ? mods + key : null;
}

function knownFolder(name) {
  const h = os.homedir();
  const m = { downloads: path.join(h, 'Downloads'), documents: path.join(h, 'Documents'), desktop: path.join(h, 'Desktop'), pictures: path.join(h, 'Pictures'), music: path.join(h, 'Music'), videos: path.join(h, 'Videos'), home: h, temp: os.tmpdir() };
  return m[name] || null;
}

// ------------------------------------------------------------------ the tool
const PROMPT =
  'You can control this Windows PC. When the user asks you to do something on the PC, reply with ONLY this JSON and nothing else: ' +
  '{"device_action":"<action>","param":"<value>"}. Actions and their param: ' +
  'open_app (app name: chrome, edge, notepad, calculator, word, excel, powerpoint, explorer, settings, camera, spotify, whatsapp, vscode, terminal, task manager, or any installed app name), ' +
  'open_url (full URL or site name), web_search (query), youtube_search (query), ' +
  'app_search ("<site or app>,<query>" - search INSIDE that site: youtube, google, maps, amazon, daraz, spotify, wikipedia, github, facebook, x, linkedin, pinterest, tiktok, reddit, imdb, stackoverflow, netflix), ' +
  'open_folder (downloads, documents, desktop, pictures, music, videos or a full path), open_file (full path), find_file (part of a file name - finds and opens the newest match), ' +
  'create_file ("<file name with extension>|<full text content>" - saved in Documents\\Cortex and opened), ' +
  'volume_up, volume_down, mute, set_volume (0-100), media_play_pause, media_next, media_prev, brightness_set (0-100), ' +
  'screenshot (saves a picture of the screen), type_text (text to type into the window the user is working in), press_keys (e.g. ctrl+c, ctrl+v, alt+tab, ctrl+s, f5, enter), ' +
  'clipboard_get, clipboard_set (text), minimize_all, switch_window, close_window, kill_app (app name to force close, e.g. chrome), ' +
  'system_info (battery, CPU, RAM, disk), battery_status, wifi_on, wifi_off, lock_pc, sleep_pc, shutdown_pc, restart_pc, cancel_shutdown, ' +
  'timer ("<seconds>,<what to remind>" - shows a notification and beeps). ' +
  'whatsapp_message ("<phone number with country code>,<message>" - opens a ready chat on WhatsApp Web). ' +
  'Use an empty param when none is needed. shutdown_pc and restart_pc wait 30 seconds so the user can say cancel_shutdown. ' +
  'If the request is not a PC action, answer normally in plain text.';

async function run(action, param, electron) {
  const { shell, Notification } = electron || {};
  const P = String(param == null ? '' : param).trim();
  const ok = (result) => ({ success: true, result: result || 'Done.' });
  const fail = (error) => ({ success: false, error: String(error || 'Failed') });
  try {
    switch (action) {
      case 'open_app': {
        const key = P.toLowerCase().replace(/\.exe$/, '');
        if (SITES[key] && !APPS[key]) { await shell.openExternal(SITES[key]); return ok('Opening ' + P + '.'); }
        const target = APPS[key] || key;
        if (/^[\w.-]+:/.test(target) || /^[\w .-]+$/.test(target)) {
          const r = await ps('Start-Process $env:CX_P', target);
          if (r.ok) return ok('Opening ' + P + '.');
        }
        // fall back to the Start menu: find any installed app by name
        const f = await ps('$a=Get-StartApps | Where-Object { $_.Name -like ("*"+$env:CX_P+"*") } | Select-Object -First 1; if($a){ Start-Process ("shell:AppsFolder\\"+$a.AppID); $a.Name } else { exit 3 }', P);
        if (f.ok) return ok('Opening ' + (f.out || P) + '.');
        return fail('I could not find an app called ' + P + '.');
      }
      case 'open_url': {
        let u = P;
        const k = u.toLowerCase();
        if (SITES[k]) u = SITES[k];
        else if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(u)) u = 'https://' + u;
        await shell.openExternal(u);
        return ok('Opening it.');
      }
      case 'web_search':
        await shell.openExternal('https://www.google.com/search?q=' + encodeURIComponent(P));
        return ok('Searching for ' + P + '.');
      case 'youtube_search':
        await shell.openExternal('https://www.youtube.com/results?search_query=' + encodeURIComponent(P));
        return ok('Searching YouTube for ' + P + '.');
      case 'app_search': {
        const i = P.indexOf(',');
        const app = (i > 0 ? P.slice(0, i) : '').trim().toLowerCase();
        const q = (i > 0 ? P.slice(i + 1) : P).trim();
        const base = SEARCH[app];
        if (base) {
          await shell.openExternal(base + (app === 'maps' || app === 'google maps' || app === 'spotify' || app === 'gmail' ? encodeURIComponent(q).replace(/%20/g, app === 'spotify' ? '%20' : '+') : encodeURIComponent(q)));
          return ok('Searching ' + app + ' for ' + q + '.');
        }
        await shell.openExternal('https://www.google.com/search?q=' + encodeURIComponent((app ? app + ' ' : '') + q));
        return ok('Searching for ' + q + '.');
      }
      case 'open_folder': {
        const k = P.toLowerCase();
        const dir = FOLDERS[k] ? knownFolder(FOLDERS[k]) : P;
        const e = await shell.openPath(dir);
        return e ? fail(e) : ok('Opening ' + (FOLDERS[k] || 'the folder') + '.');
      }
      case 'open_file': {
        const e = await shell.openPath(P);
        return e ? fail(e) : ok('Opening the file.');
      }
      case 'find_file': {
        const r = await ps('Get-ChildItem -Path $env:USERPROFILE -Recurse -Depth 5 -File -ErrorAction SilentlyContinue -Filter ("*"+$env:CX_P+"*") | Sort-Object LastWriteTime -Descending | Select-Object -First 5 -ExpandProperty FullName', P, 40000);
        const list = r.out.split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
        if (!list.length) return fail('I could not find a file named ' + P + '.');
        await shell.openPath(list[0]);
        return ok('Found ' + list.length + (list.length > 1 ? ' files. Opening the newest: ' : ' file: ') + path.basename(list[0]) + '.');
      }
      case 'create_file': {
        const i = P.indexOf('|');
        let name = (i > 0 ? P.slice(0, i) : 'note.txt').replace(/[\\/:*?"<>|]/g, '_').trim() || 'note.txt';
        if (!/\.[A-Za-z0-9]{1,5}$/.test(name)) name += '.txt';
        const content = i > 0 ? P.slice(i + 1) : P;
        const dir = path.join(os.homedir(), 'Documents', 'Cortex');
        fs.mkdirSync(dir, { recursive: true });
        const file = path.join(dir, name);
        fs.writeFileSync(file, content, 'utf-8');
        await shell.openPath(file);
        return ok('Saved ' + name + ' in Documents, Cortex folder and opened it.');
      }
      case 'volume_up':
        await ps('$w=New-Object -ComObject WScript.Shell; 1..5|ForEach-Object{$w.SendKeys([char]175)}');
        return ok('Volume up.');
      case 'volume_down':
        await ps('$w=New-Object -ComObject WScript.Shell; 1..5|ForEach-Object{$w.SendKeys([char]174)}');
        return ok('Volume down.');
      case 'mute':
        await ps('(New-Object -ComObject WScript.Shell).SendKeys([char]173)');
        return ok('Done.');
      case 'set_volume': {
        const n = clamp(num(P, 50), 0, 100);
        await ps('$w=New-Object -ComObject WScript.Shell; 1..50|ForEach-Object{$w.SendKeys([char]174)}; $n=[int]([int]$env:CX_P/2); if($n -gt 0){1..$n|ForEach-Object{$w.SendKeys([char]175)}}', n);
        return ok('Volume set to about ' + n + ' percent.');
      }
      case 'media_play_pause':
        await ps('(New-Object -ComObject WScript.Shell).SendKeys([char]179)');
        return ok('Done.');
      case 'media_next':
        await ps('(New-Object -ComObject WScript.Shell).SendKeys([char]176)');
        return ok('Next track.');
      case 'media_prev':
        await ps('(New-Object -ComObject WScript.Shell).SendKeys([char]177)');
        return ok('Previous track.');
      case 'brightness_set': {
        const n = clamp(num(P, 60), 0, 100);
        const r = await ps('(Get-WmiObject -Namespace root/WMI -Class WmiMonitorBrightnessMethods).WmiSetBrightness(1,[int]$env:CX_P)', n);
        return r.ok ? ok('Brightness set to ' + n + ' percent.') : fail('This screen does not allow changing brightness.');
      }
      case 'screenshot': {
        const r = await ps(
          'Add-Type -AssemblyName System.Windows.Forms,System.Drawing; $b=[System.Windows.Forms.SystemInformation]::VirtualScreen; ' +
            '$bmp=New-Object System.Drawing.Bitmap $b.Width,$b.Height; $g=[System.Drawing.Graphics]::FromImage($bmp); $g.CopyFromScreen($b.Left,$b.Top,0,0,$bmp.Size); ' +
            '$d=Join-Path ([Environment]::GetFolderPath("MyPictures")) "Cortex"; New-Item -ItemType Directory -Force $d | Out-Null; ' +
            '$f=Join-Path $d ("screenshot-"+(Get-Date -Format "yyyyMMdd-HHmmss")+".png"); $bmp.Save($f); $f'
        );
        if (!r.ok || !r.out) return fail('Could not take the screenshot.');
        try { shell.showItemInFolder(r.out.split(/\r?\n/).pop()); } catch (e) {}
        return ok('Screenshot saved in Pictures, Cortex folder.');
      }
      case 'type_text': {
        if (!P) return fail('There is nothing to type.');
        const r = await ps('Set-Clipboard -Value $env:CX_P; Start-Sleep -Milliseconds 250; ' + SENDKEYS + '[System.Windows.Forms.SendKeys]::SendWait("^v")', P);
        return r.ok ? ok('Typed it.') : fail('I could not type that.');
      }
      case 'press_keys': {
        const k = P.toLowerCase().replace(/\s+/g, '');
        if (k === 'win+d') return run('minimize_all', '', electron);
        if (k === 'win+e') return run('open_app', 'explorer', electron);
        if (k === 'win+l') return run('lock_pc', '', electron);
        if (k === 'win+r') return run('open_app', 'cmd', electron);
        const sk = keysToSendKeys(P);
        if (!sk) return fail('I do not know the key combination ' + P + '.');
        const r = await ps(SENDKEYS + '[System.Windows.Forms.SendKeys]::SendWait($env:CX_P)', sk);
        return r.ok ? ok('Pressed ' + P + '.') : fail('Could not press the keys.');
      }
      case 'clipboard_get': {
        const r = await ps('Get-Clipboard -Raw');
        return ok(r.out ? 'The clipboard has: ' + r.out.slice(0, 300) : 'The clipboard is empty.');
      }
      case 'clipboard_set':
        await ps('Set-Clipboard -Value $env:CX_P', P);
        return ok('Copied.');
      case 'minimize_all':
        await ps('(New-Object -ComObject Shell.Application).MinimizeAll()');
        return ok('Done.');
      case 'switch_window':
        await ps(SENDKEYS + '[System.Windows.Forms.SendKeys]::SendWait("%{TAB}")');
        return ok('Switched.');
      case 'close_window':
        await ps(SENDKEYS + '[System.Windows.Forms.SendKeys]::SendWait("%{F4}")');
        return ok('Closed.');
      case 'kill_app': {
        let n = P.toLowerCase().replace(/\.exe$/, '').trim();
        n = PROC[n] || n;
        if (!/^[\w .-]{1,40}$/.test(n) || NEVER_KILL.test(n)) return fail('I will not close that.');
        const r = await ps('Stop-Process -Name $env:CX_P -Force -ErrorAction Stop', n);
        return r.ok ? ok('Closed ' + P + '.') : fail(P + ' is not running.');
      }
      case 'system_info':
      case 'battery_status': {
        const r = await ps(
          '$b=Get-CimInstance Win32_Battery; $o=Get-CimInstance Win32_OperatingSystem; ' +
            '$c=(Get-CimInstance Win32_Processor | Measure-Object -Property LoadPercentage -Average).Average; ' +
            '$ram=[math]::Round((($o.TotalVisibleMemorySize-$o.FreePhysicalMemory)/$o.TotalVisibleMemorySize)*100); ' +
            '$free=[math]::Round((Get-PSDrive C).Free/1GB); ' +
            '$bat= if($b){ [string]$b.EstimatedChargeRemaining + " percent" + $(if($b.BatteryStatus -eq 2){", charging"}else{""}) } else { "no battery" }; ' +
            '"Battery $bat. Processor $c percent busy. Memory $ram percent used. Drive C has $free gigabytes free."'
        );
        if (!r.out) return fail('Could not read the system information.');
        return ok(action === 'battery_status' ? r.out.split('.')[0] + '.' : r.out);
      }
      case 'wifi_on':
        return await new Promise((res) => exec('netsh interface set interface "Wi-Fi" enabled', (e) => res(e ? fail('Wi-Fi needs Cortex to run as administrator.') : ok('Wi-Fi on.'))));
      case 'wifi_off':
        return await new Promise((res) => exec('netsh interface set interface "Wi-Fi" disabled', (e) => res(e ? fail('Wi-Fi needs Cortex to run as administrator.') : ok('Wi-Fi off.'))));
      case 'lock_pc':
        exec('rundll32.exe user32.dll,LockWorkStation');
        return ok('Locking the PC.');
      case 'sleep_pc':
        exec('rundll32.exe powrprof.dll,SetSuspendState 0,1,0');
        return ok('Going to sleep.');
      case 'shutdown_pc':
        exec('shutdown /s /t 30');
        return ok('The PC will shut down in 30 seconds. Say cancel shutdown to stop it.');
      case 'restart_pc':
        exec('shutdown /r /t 30');
        return ok('The PC will restart in 30 seconds. Say cancel shutdown to stop it.');
      case 'cancel_shutdown':
        exec('shutdown /a');
        return ok('Shutdown cancelled.');
      case 'timer': {
        const i = P.indexOf(',');
        const secs = clamp(num(i > 0 ? P.slice(0, i) : P, 60), 1, 86400);
        const label = (i > 0 ? P.slice(i + 1) : 'Timer finished').trim() || 'Timer finished';
        setTimeout(() => {
          try { if (Notification && Notification.isSupported()) new Notification({ title: 'Cortex', body: label }).show(); } catch (e) {}
          try { shell.beep(); setTimeout(() => shell.beep(), 600); } catch (e) {}
        }, secs * 1000);
        return ok('Okay, I will remind you in ' + (secs >= 60 ? Math.round(secs / 60) + ' minutes' : secs + ' seconds') + '.');
      }
      case 'whatsapp_message': {
        const i = P.indexOf(',');
        const num2 = (i > 0 ? P.slice(0, i) : '').replace(/[^\d]/g, '');
        const msg = i > 0 ? P.slice(i + 1).trim() : P;
        if (!num2) return fail('I need the phone number with the country code.');
        await shell.openExternal('https://wa.me/' + num2 + '?text=' + encodeURIComponent(msg));
        return ok('WhatsApp chat is open with your message ready. Press send.');
      }
      default:
        return fail('Unknown action: ' + action);
    }
  } catch (err) {
    return fail((err && err.message) || String(err));
  }
}

module.exports = { run, PROMPT, keysToSendKeys };
