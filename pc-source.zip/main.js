const { app, BrowserWindow, ipcMain, shell, session, Tray, Menu, screen, globalShortcut, Notification } = require('electron');
const path = require('path');
const fs = require('fs');
const { exec, spawn } = require('child_process');

const SETTINGS_PATH = path.join(app.getPath('userData'), 'asfar-settings.json');
const CHAT_PATH = path.join(app.getPath('userData'), 'asfar-chat.json');

// Model IDs we used to ship as defaults that Google/OpenAI have since retired.
// If someone's saved settings still point at one of these, clear it so the
// fallback chain in the Gemini call (and each provider's own current default) takes over.
const STALE_MODELS = ['gemini-2.5-flash', 'gemini-2.5-flash-lite', 'gemini-2.0-flash-001'];
const DEFAULT_SETTINGS = { provider: 'anthropic', apiKey: '', model: '', wakeWordEnabled: true, developerName: '' };

function loadSettings() {
  try {
    const raw = fs.readFileSync(SETTINGS_PATH, 'utf-8');
    const settings = { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
    if (STALE_MODELS.includes(settings.model)) settings.model = '';
    return settings;
  } catch (e) {
    return { ...DEFAULT_SETTINGS };
  }
}

function saveSettings(settings) {
  fs.writeFileSync(SETTINGS_PATH, JSON.stringify(settings, null, 2), 'utf-8');
}

function loadChatHistory() {
  try {
    return JSON.parse(fs.readFileSync(CHAT_PATH, 'utf-8'));
  } catch (e) {
    return [];
  }
}

function saveChatHistory(messages) {
  fs.writeFileSync(CHAT_PATH, JSON.stringify(messages, null, 2), 'utf-8');
}

const APPDATA_PATH = path.join(app.getPath('userData'), 'asfar-appdata.json');
const DEFAULT_APPDATA = { tasks: [], activity: [], stats: { messagesSent: 0, agentReplies: 0, wakeActivations: 0 } };

function loadAppData() {
  try {
    return { ...DEFAULT_APPDATA, ...JSON.parse(fs.readFileSync(APPDATA_PATH, 'utf-8')) };
  } catch (e) {
    return { ...DEFAULT_APPDATA };
  }
}

function saveAppData(data) {
  fs.writeFileSync(APPDATA_PATH, JSON.stringify(data, null, 2), 'utf-8');
}

let mainWindow;
let popupWin = null;
let popupLoaded = false;
let popupVisible = false;
let tray = null;
let isQuitting = false;
let wakeProc = null;
let wakeRestarts = 0;
let lastWakeAt = 0;

// ---------------------------------------------------------------------------
// Always-on "Hey Cortex" (Windows' own offline speech engine, no internet, no key)
// ---------------------------------------------------------------------------
const WAKE_PS = [
  'Add-Type -AssemblyName System.Speech',
  '$engine = $null',
  'try { $engine = New-Object System.Speech.Recognition.SpeechRecognitionEngine((New-Object System.Globalization.CultureInfo("en-US"))) } catch { }',
  'if ($engine -eq $null) { $engine = New-Object System.Speech.Recognition.SpeechRecognitionEngine }',
  '$choices = New-Object System.Speech.Recognition.Choices',
  "foreach ($p in 'hey cortex','hi cortex','ok cortex','okay cortex','hey cortes','hey codex') { $choices.Add($p) }",
  '$gb = New-Object System.Speech.Recognition.GrammarBuilder',
  '$gb.Culture = $engine.RecognizerInfo.Culture',
  '$gb.Append($choices)',
  '$engine.LoadGrammar((New-Object System.Speech.Recognition.Grammar($gb)))',
  '$engine.SetInputToDefaultAudioDevice()',
  'Register-ObjectEvent -InputObject $engine -EventName SpeechRecognized -Action {',
  '  if ($Event.SourceEventArgs.Result.Confidence -ge 0.78) { [Console]::Out.WriteLine("WAKE"); [Console]::Out.Flush() }',
  '} | Out-Null',
  '$engine.RecognizeAsync([System.Speech.Recognition.RecognizeMode]::Multiple)',
  '[Console]::Out.WriteLine("READY"); [Console]::Out.Flush()',
  'while ($true) { Start-Sleep -Seconds 1 }',
].join('\r\n');

function setTrayTip(text) {
  if (tray) tray.setToolTip(text);
}

function startWake() {
  if (process.platform !== 'win32' || wakeProc || isQuitting) return;
  try {
    const file = path.join(app.getPath('userData'), 'cortex-wake.ps1');
    fs.writeFileSync(file, WAKE_PS, 'utf-8');
    wakeProc = spawn(
      'powershell.exe',
      ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', file],
      { windowsHide: true }
    );
    let buf = '';
    wakeProc.stdout.on('data', (d) => {
      buf += d.toString();
      let i;
      while ((i = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, i).trim();
        buf = buf.slice(i + 1);
        if (line === 'READY') {
          wakeRestarts = 0;
          setTrayTip('Cortex — listening for "Hey Cortex" (or press Ctrl+Alt+C)');
        } else if (line === 'WAKE') {
          onWake();
        }
      }
    });
    wakeProc.stderr.on('data', (d) => console.error('wake engine:', d.toString()));
    wakeProc.on('exit', () => {
      wakeProc = null;
      const s = loadSettings();
      if (s.wakeWordEnabled && !isQuitting) {
        wakeRestarts += 1;
        if (wakeRestarts <= 5) {
          setTimeout(startWake, 3000);
        } else {
          setTrayTip('Cortex — voice wake unavailable on this PC. Press Ctrl+Alt+C to talk.');
        }
      }
    });
  } catch (e) {
    wakeProc = null;
    setTrayTip('Cortex — voice wake unavailable. Press Ctrl+Alt+C to talk.');
  }
}

function stopWake() {
  if (wakeProc) {
    const p = wakeProc;
    wakeProc = null;
    try {
      p.removeAllListeners('exit');
      p.kill();
    } catch (e) {}
  }
  setTrayTip('Cortex — wake word is off. Press Ctrl+Alt+C to talk.');
}

function applyWake(settings) {
  if (settings && settings.wakeWordEnabled) startWake();
  else stopWake();
}

function onWake() {
  const now = Date.now();
  if (now - lastWakeAt < 1500 || popupVisible) return;
  lastWakeAt = now;
  showPopup();
}

// ---------------------------------------------------------------------------
// Small always-on-top popup that talks (like the phone version)
// ---------------------------------------------------------------------------
function createPopup() {
  popupLoaded = false;
  popupWin = new BrowserWindow({
    width: 400,
    height: 240,
    frame: false,
    transparent: true,
    resizable: false,
    alwaysOnTop: true,
    skipTaskbar: true,
    show: false,
    hasShadow: false,
    webPreferences: {
      preload: path.join(__dirname, 'popup-preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      backgroundThrottling: false,
    },
  });
  popupWin.setAlwaysOnTop(true, 'screen-saver');
  popupWin.loadFile(path.join(__dirname, 'renderer', 'popup.html'));
  popupWin.webContents.once('did-finish-load', () => {
    popupLoaded = true;
    if (popupVisible) popupWin.webContents.send('popup:show');
  });
  popupWin.on('close', (event) => {
    if (!isQuitting) {
      event.preventDefault();
      hidePopup();
    }
  });
}

function showPopup() {
  if (!popupWin) createPopup();
  const area = screen.getPrimaryDisplay().workArea;
  popupWin.setPosition(Math.round(area.x + (area.width - 400) / 2), area.y + 24);
  popupVisible = true;
  popupWin.showInactive();
  if (popupLoaded) popupWin.webContents.send('popup:show');
}

function hidePopup() {
  popupVisible = false;
  if (popupWin) {
    try {
      popupWin.webContents.send('popup:hide');
    } catch (e) {}
    popupWin.hide();
  }
}

function createWindow() {
  const startHidden = process.argv.includes('--hidden');

  mainWindow = new BrowserWindow({
    width: 1180,
    height: 780,
    minWidth: 860,
    minHeight: 600,
    backgroundColor: '#0B0E14',
    titleBarStyle: 'hiddenInset',
    show: !startHidden,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  mainWindow.loadFile(path.join(__dirname, 'renderer', 'index.html'));

  // Closing the window just hides it — Cortex keeps listening for "Hey Cortex"
  // in the background, same as Siri/Google Assistant do on a phone. Only the
  // tray menu's "Quit Cortex" actually exits.
  mainWindow.on('close', (event) => {
    if (!isQuitting) {
      event.preventDefault();
      mainWindow.hide();
    }
  });
}

function createTray() {
  tray = new Tray(path.join(__dirname, 'renderer', 'tray-icon.png'));
  tray.setToolTip('Cortex — listening for "Hey Cortex"');
  const menu = Menu.buildFromTemplate([
    {
      label: 'Show Cortex',
      click: () => {
        mainWindow.show();
        mainWindow.focus();
      },
    },
    {
      label: 'Talk to Cortex (Ctrl+Alt+C)',
      click: () => showPopup(),
    },
    { type: 'separator' },
    {
      label: 'Quit Cortex',
      click: () => {
        isQuitting = true;
        app.quit();
      },
    },
  ]);
  tray.setContextMenu(menu);
  tray.on('click', () => {
    mainWindow.show();
    mainWindow.focus();
  });
}

if (!app.requestSingleInstanceLock()) {
  app.quit();
}
app.on('second-instance', () => {
  if (mainWindow) {
    mainWindow.show();
    mainWindow.focus();
  }
});

app.whenReady().then(() => {
  // Electron doesn't show the same permission-prompt flow as regular Chrome —
  // without this, getUserMedia (microphone, for voice + wake word) is silently
  // denied every time, which is why mic/wake-word never worked.
  session.defaultSession.setPermissionRequestHandler((_webContents, permission, callback) => {
    if (permission === 'media') {
      callback(true);
    } else {
      callback(false);
    }
  });
  session.defaultSession.setPermissionCheckHandler((_webContents, permission) => {
    return permission === 'media';
  });

  createWindow();
  createTray();
  applyWake(loadSettings());
  try {
    globalShortcut.register('Control+Alt+C', () => (popupVisible ? hidePopup() : showPopup()));
  } catch (e) {}

  // Auto-start with Windows: Cortex registers itself to launch quietly into
  // the tray on boot, the same way it already stays running in the tray
  // instead of closing. Shutting down Windows stops it automatically too —
  // that part needs no code, it's how every background process works.
  app.setLoginItemSettings({
    openAtLogin: true,
    path: app.getPath('exe'),
    args: ['--hidden'],
  });

  // Renderer tells us when it hears "hey cortex" so we can bring the (possibly
  // hidden/background) window to the front, like Siri popping up.
  ipcMain.on('wake:triggered', () => {
    if (mainWindow) {
      mainWindow.show();
      mainWindow.focus();
    }
  });

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('before-quit', () => {
  isQuitting = true;
  stopWake();
  try {
    globalShortcut.unregisterAll();
  } catch (e) {}
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

// ---- IPC: settings ----
ipcMain.handle('settings:get', () => loadSettings());
ipcMain.handle('settings:set', (_evt, settings) => {
  saveSettings(settings);
  applyWake(settings);
  return true;
});

// ---- IPC: popup ----
ipcMain.on('popup:open', () => showPopup());
ipcMain.on('popup:close', () => hidePopup());

// ---- IPC: chat history ----
ipcMain.handle('chat:get', () => loadChatHistory());
ipcMain.handle('chat:set', (_evt, messages) => {
  saveChatHistory(messages);
  return true;
});

// ---- IPC: app data (tasks / activity / stats) ----
ipcMain.handle('appdata:get', () => loadAppData());
ipcMain.handle('appdata:set', (_evt, data) => {
  saveAppData(data);
  return true;
});

// ---- IPC: LLM call ----
// Runs in the main process so the request is a plain Node fetch (no browser CORS restrictions).
// ---- EDIT THIS after deploying your Cloudflare Worker ----
const WORKER_URL = 'https://cortexai.asadjuiya7.workers.dev';

ipcMain.handle('llm:call', async (_evt, { messages, system }) => {
  const settings = loadSettings();
  const { licenseKey } = settings;
  const hasParts = messages.some((m) => Array.isArray(m.content));
  const provider = hasParts ? 'gemini' : settings.provider;

  if (!licenseKey) {
    return { error: 'No license key set. Open Settings and add your license key first.' };
  }

  try {
    const res = await fetch(WORKER_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        provider,
        messages: messages.map((m) => ({ role: m.role, content: m.content })),
        system,
        license_key: licenseKey,
      }),
    });
    const data = await res.json();
    if (data.error) return { error: data.error };
    return { text: data.text };
  } catch (err) {
    return { error: (err && err.message) || 'Could not reach Cortex.' };
  }
});

// ---- IPC: developer request (owner only; the Worker checks the license) ----
ipcMain.handle('dev:request', async (_evt, { text, target }) => {
  const { licenseKey } = loadSettings();
  if (!licenseKey) return { error: 'no_license' };
  try {
    const res = await fetch(WORKER_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'dev_request', license_key: licenseKey, text, target: target || 'pc' }),
    });
    return await res.json();
  } catch (err) {
    return { error: (err && err.message) || 'network' };
  }
});

// ---- IPC: PC device actions ----
// Unlike a browser tab, the Electron main process has full OS access, so basic
// PC control needs no external automation tool (no AutoHotkey/MacroDroid needed
// for these). More advanced things (simulating clicks inside other apps) would
// need something like AutoHotkey — not implemented here.
const pcctl = require('./pcctl');
ipcMain.on('pc:prompt', (e) => { e.returnValue = pcctl.PROMPT; });
ipcMain.handle('system:action', async (_evt, { action, param }) => {
  return pcctl.run(String(action || ''), param, { shell, Notification });
});
