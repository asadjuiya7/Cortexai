(function () {
  const statusEl = document.getElementById('status');
  const bodyEl = document.getElementById('body');
  const api = window.cortexPopup;

  let stream = null, ctx = null, proc = null, src = null;
  let active = false, busy = false, speaking = false;
  let history = [];
  let lastActivity = Date.now();
  let idleTimer = null;
  let speakTimer = null;
  let urduVoice = null;
  let hindiVoice = null;
  let engVoice = null;

  // voice-activity detector state
  let noise = 0.006, inSpeech = false, voicedRun = 0, speechFrames = 0, silence = 0;
  let pre = [], chunks = [], totalSamples = 0;

  function setStatus(t) { statusEl.textContent = t; }
  function setBody(t) { bodyEl.textContent = t; }

  function pickVoices() {
    const vs = speechSynthesis.getVoices();
    urduVoice = vs.find((v) => /^ur/i.test(v.lang)) || null;
    hindiVoice = vs.find((v) => /^hi/i.test(v.lang)) || null;
    engVoice =
      vs.find((v) => /^en/i.test(v.lang) && /natural|online|aria|jenny|guy/i.test(v.name)) ||
      vs.find((v) => /^en-US/i.test(v.lang)) ||
      vs.find((v) => /^en/i.test(v.lang)) ||
      null;
  }
  speechSynthesis.onvoiceschanged = pickVoices;
  pickVoices();

  function buildSystem() {
    const urduRule = urduVoice
      ? 'If the user speaks Urdu, reply in Urdu script.'
      : 'If the user speaks Urdu or Hindi, reply in Roman Urdu (Urdu written with English letters), never in Urdu script.';
    return (
      'You are Cortex, a friendly voice assistant on a Windows PC. Your developer is Muhammad Asad Ashraf, but never mention it unless the user directly asks who made you. ' +
      'Never say you were made by Google, OpenAI or Anthropic and never mention Gemini, GPT or Claude. ' +
      'Reply in at most two short sentences, plain text only, no markdown, no lists, no emojis. ' +
      'Reply in the language the user speaks. ' + urduRule + ' ' +
      "The user's messages arrive as voice audio, so listen to the audio. " +
      'If the audio has no clear human speech meant for you (background noise, TV, other people, silence), reply with exactly the single word IGNORE. ' +
      'If the user says stop, bye, cancel or close, reply with exactly the single word STOP. ' +
      api.pcPrompt + ' ' +
      'If the user asks to change, fix or add a feature of the Cortex app or its software itself, reply with ONLY {"dev_request":"<clear detailed English description>","target":"android" or "pc" or "both"}. ' +
      'If the request is not a PC action, just answer normally in plain text.'
    );
  }

  // ---------------------------------------------------------------- microphone + simple speech detector
  function resetVad() {
    inSpeech = false; voicedRun = 0; speechFrames = 0; silence = 0;
    pre = []; chunks = []; totalSamples = 0;
  }

  async function start() {
    if (active) return;
    active = true; busy = false; speaking = false;
    history = []; lastActivity = Date.now();
    setStatus('Listening...');
    setBody("Go ahead, I'm listening.");
    try {
      stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
      });
    } catch (e) {
      setStatus('Microphone problem');
      setBody('Cortex cannot use the microphone. Check Windows Settings → Privacy → Microphone.');
      active = false;
      return;
    }
    ctx = new AudioContext({ sampleRate: 16000 });
    src = ctx.createMediaStreamSource(stream);
    proc = ctx.createScriptProcessor(512, 1, 1);
    src.connect(proc);
    proc.connect(ctx.destination);
    resetVad();
    proc.onaudioprocess = onAudio;
    idleTimer = setInterval(() => {
      if (!busy && !speaking && Date.now() - lastActivity > 120000) closeMe();
    }, 5000);
  }

  function stop() {
    active = false;
    clearInterval(idleTimer);
    clearTimeout(speakTimer);
    try { if (proc) { proc.onaudioprocess = null; proc.disconnect(); } } catch (e) {}
    try { if (src) src.disconnect(); } catch (e) {}
    try { if (ctx) ctx.close(); } catch (e) {}
    try { if (stream) stream.getTracks().forEach((t) => t.stop()); } catch (e) {}
    stream = ctx = proc = src = null;
    try { speechSynthesis.cancel(); } catch (e) {}
  }

  function closeMe() {
    stop();
    api.close();
  }

  function onAudio(e) {
    if (!active || busy || speaking) return;
    const d = e.inputBuffer.getChannelData(0);
    let sum = 0;
    for (let i = 0; i < d.length; i++) sum += d[i] * d[i];
    const rms = Math.sqrt(sum / d.length);
    const thr = Math.max(0.015, noise * 2.6);
    const voiced = rms > thr;
    const frame = new Int16Array(d.length);
    for (let i = 0; i < d.length; i++) frame[i] = Math.max(-1, Math.min(1, d[i])) * 32767;

    if (!inSpeech) {
      noise = noise * 0.97 + rms * 0.03;
      pre.push(frame);
      if (pre.length > 10) pre.shift();
      voicedRun = voiced ? voicedRun + 1 : 0;
      if (voicedRun >= 4) {
        inSpeech = true;
        chunks = pre.slice();
        totalSamples = chunks.reduce((n, c) => n + c.length, 0);
        speechFrames = voicedRun;
        silence = 0;
        setStatus('Hearing you...');
      }
      return;
    }
    chunks.push(frame);
    totalSamples += frame.length;
    if (voiced) { speechFrames++; silence = 0; } else { silence++; }
    // about 0.8 s of quiet ends the sentence (25 frames of 32 ms), or 14 s maximum
    if (silence >= 25 || totalSamples > 16000 * 14) {
      const good = speechFrames >= 10;
      const data = chunks;
      resetVad();
      if (good) {
        busy = true;
        send(data);
      } else {
        setStatus('Listening...');
      }
    }
  }

  // ---------------------------------------------------------------- talk to the AI
  function wavBase64(parts) {
    let n = 0;
    parts.forEach((p) => (n += p.length));
    const buf = new ArrayBuffer(44 + n * 2);
    const v = new DataView(buf);
    const w = (o, s) => { for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); };
    w(0, 'RIFF'); v.setUint32(4, 36 + n * 2, true); w(8, 'WAVE'); w(12, 'fmt ');
    v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
    v.setUint32(24, 16000, true); v.setUint32(28, 32000, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true);
    w(36, 'data'); v.setUint32(40, n * 2, true);
    let off = 44;
    parts.forEach((p) => { for (let i = 0; i < p.length; i++, off += 2) v.setInt16(off, p[i], true); });
    const bytes = new Uint8Array(buf);
    let bin = '';
    for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    return btoa(bin);
  }

  function friendly(err) {
    const e = String(err || '');
    if (/trial_expired/.test(e)) return 'Your trial has ended. Please renew your license.';
    if (/revoked|not_found|invalid_license/.test(e)) return 'This license is not active.';
    if (/license_required|No license key/i.test(e)) return 'Open Cortex once and add your license key in Settings.';
    if (/quota|exhausted|429|limit|busy/i.test(e)) return 'Cortex is very busy right now. Please try again in a minute.';
    return e || 'Could not reach Cortex. Check your internet.';
  }

  function resumeListening(delay) {
    setTimeout(() => {
      if (!active) return;
      resetVad();
      busy = false;
      speaking = false;
      lastActivity = Date.now();
      setStatus('Listening...');
    }, delay);
  }

  async function send(parts) {
    lastActivity = Date.now();
    setStatus('Thinking...');
    const audio = {
      role: 'user',
      content: [
        { inlineData: { mimeType: 'audio/wav', data: wavBase64(parts) } },
        { text: "(This is the user's voice message. Listen and respond.)" },
      ],
    };
    let res;
    try {
      res = await api.callLLM(history.slice(-12).concat([audio]), buildSystem());
    } catch (e) {
      res = { error: 'Could not reach Cortex. Check your internet.' };
    }
    if (!active) return;
    if (res.error) {
      setStatus('Cortex');
      setBody(friendly(res.error));
      resumeListening(7000);
      return;
    }
    const raw = (res.text || '').trim();
    const bare = raw.replace(/^[\s."*]+|[\s."*]+$/g, '').toUpperCase();
    if (bare === 'IGNORE') { resumeListening(50); return; }
    if (bare === 'STOP') { closeMe(); return; }
    history.push({ role: 'user', content: '(voice message)' });

    const dev = parseDev(raw);
    if (dev) {
      history.push({ role: 'assistant', content: '(sent a change request)' });
      setStatus('Sending to developer agent...');
      setBody(dev.text.slice(0, 160));
      let r;
      try { r = await api.devRequest(dev.text, dev.target); } catch (e) { r = { error: 'network' }; }
      let say;
      if (r && r.ok) say = 'Okay, I sent your request to the developer agent. You can approve it on GitHub when it is ready.';
      else if (r && r.error === 'not_owner') say = 'Only the Cortex developer can do that.';
      else if (r && r.error === 'dev_not_configured') say = 'The developer agent is not set up yet.';
      else say = 'I could not send the request.';
      setStatus('Cortex');
      setBody(say);
      speak(say);
      return;
    }

    const act = parseAction(raw);
    if (act) {
      history.push({ role: 'assistant', content: raw });
      let r;
      try { r = await api.runAction(act.action, act.param); } catch (e) { r = { success: false, error: String(e) }; }
      const say = r && r.success ? (r.result || 'Done.') : ((r && r.error) || 'Sorry, I could not do that.');
      history.push({ role: 'assistant', content: say });
      setStatus('Cortex');
      setBody(say);
      speak(say);
      return;
    }
    const reply = raw.replace(/[*#`_]/g, '').trim();
    if (!reply) { resumeListening(50); return; }
    history.push({ role: 'assistant', content: reply });
    setStatus('Cortex');
    setBody(reply);
    speak(reply);
  }

  function parseDev(text) {
    const t = text.trim().replace(/^```(?:json)?\s*/i, '').replace(/```\s*$/i, '').trim();
    if (!t.startsWith('{') || !t.endsWith('}')) return null;
    try {
      const x = JSON.parse(t);
      if (x.dev_request) return { text: String(x.dev_request), target: String(x.target || 'pc') };
    } catch (e) {}
    return null;
  }

  function parseAction(text) {
    const t = text.trim().replace(/^```(?:json)?\s*/i, '').replace(/```\s*$/i, '').trim();
    if (!t.startsWith('{') || !t.endsWith('}')) return null;
    try {
      const j = JSON.parse(t);
      if (j.device_action) return { action: String(j.device_action), param: String(j.param || '') };
    } catch (e) {}
    return null;
  }

  function speak(text) {
    speaking = true;
    setStatus('Speaking...');
    const u = new SpeechSynthesisUtterance(text);
    const arabic = /[؀-ۿ]/.test(text);
    const deva = /[ऀ-ॿ]/.test(text);
    if (arabic && urduVoice) { u.voice = urduVoice; u.lang = urduVoice.lang; }
    else if (deva && hindiVoice) { u.voice = hindiVoice; u.lang = hindiVoice.lang; }
    else if (engVoice) { u.voice = engVoice; u.lang = engVoice.lang; }
    u.rate = 1;
    let finished = false;
    const done = () => {
      if (finished) return;
      finished = true;
      clearTimeout(speakTimer);
      resumeListening(450);
    };
    u.onend = done;
    u.onerror = done;
    clearTimeout(speakTimer);
    speakTimer = setTimeout(done, 40000);
    speechSynthesis.cancel();
    speechSynthesis.speak(u);
  }

  document.getElementById('x').addEventListener('click', closeMe);
  api.onShow(() => { start(); });
  api.onHide(() => { stop(); });
})();
