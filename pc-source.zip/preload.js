const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('asfar', {
  getSettings: () => ipcRenderer.invoke('settings:get'),
  setSettings: (settings) => ipcRenderer.invoke('settings:set', settings),
  callLLM: (messages, system) => ipcRenderer.invoke('llm:call', { messages, system }),
  getChatHistory: () => ipcRenderer.invoke('chat:get'),
  setChatHistory: (messages) => ipcRenderer.invoke('chat:set', messages),
  getAppData: () => ipcRenderer.invoke('appdata:get'),
  setAppData: (data) => ipcRenderer.invoke('appdata:set', data),
  runPcAction: (action, param) => ipcRenderer.invoke('system:action', { action, param }),
  openPopup: () => ipcRenderer.send('popup:open'),
  pcPrompt: ipcRenderer.sendSync('pc:prompt'),
  hasNativeWake: true,
  notifyWakeTriggered: () => ipcRenderer.send('wake:triggered'),
});
