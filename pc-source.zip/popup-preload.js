const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('cortexPopup', {
  onShow: (cb) => ipcRenderer.on('popup:show', () => cb()),
  onHide: (cb) => ipcRenderer.on('popup:hide', () => cb()),
  callLLM: (messages, system) => ipcRenderer.invoke('llm:call', { messages, system }),
  runAction: (action, param) => ipcRenderer.invoke('system:action', { action, param }),
  devRequest: (text, target) => ipcRenderer.invoke('dev:request', { text, target }),
  pcPrompt: ipcRenderer.sendSync('pc:prompt'),
  close: () => ipcRenderer.send('popup:close'),
});
